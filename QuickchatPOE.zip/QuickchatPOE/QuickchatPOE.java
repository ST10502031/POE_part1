/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package mycompany.quickchatpoe;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author abbyluxe
 */
public class QuickchatPOE {

     // Registered user info
        static String registeredUsername;
        static String registeredPassword;
        static String registeredPhone;
        
        // Message counters
        public static int totalMessageSent = 0;
        public static int messageNumber = 0;
       
        // === Message Data Storage (From Part/TaskManager) ===
        static ArrayList<String> sentMessages = new ArrayList<>();
        static ArrayList<String> disregardedMessages = new ArrayList<>();
        static ArrayList<String> storedMessages = new ArrayList<>();
        static ArrayList<String> recipients = new ArrayList<>();
        static ArrayList<String> messageIDs = new ArrayList<>();
        static ArrayList<String> messageHashes = new ArrayList<>();
        
        public static void main(String[] args) {
            JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");
            registerUser();
            
            if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Login successful. Redirecting to QuickChat...");
             runMainMenu();
            } else {
                JOptionPane.showMessageDialog(null, "Login failed. Exiting app.");
            }
        }
    
        public static void registerUser() {
           boolean valid = false;
            while (valid) {
                registeredUsername = JOptionPane.showInputDialog("Create a username (must contain _ and max 5 chars):");
                if (!(registeredUsername != null && registeredUsername.contains("_")&& registeredUsername.length()<= 5)) {
                    JOptionPane.showMessageDialog(null, "invalid username");
                    continue;
                }    
            registeredPassword = JOptionPane.showInputDialog("Create password (8+ chars, 1 capital, 1 number, 1 special):");
            if (registeredPassword != null && registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")) {
                JOptionPane.showMessageDialog(null, "invalid password.");
                continue;
            }
            registeredPhone = JOptionPane.showInputDialog("Enter phone number (+27*********):");
            if (!(registeredPhone != null && registeredPhone.matches("\\+27[6-8]\\d{8}$"))) {
                JOptionPane.showMessageDialog(null, "Valid phone number.");
                continue;
            }
        JOptionPane.showMessageDialog(null, "Registration successful!");
         valid = true;
                }
            }
         
       public static boolean loginUser() { 
           String user = JOptionPane.showInputDialog("Enter your username:"); 
           String pass = JOptionPane.showInputDialog("Enter your password:"); 
           return user != null && user.equals(registeredUsername) && pass != null && pass.equals(registeredPassword);
      }        
       
        // Main menu with messages system & details options 
       public static void  runMainMenu() {
           boolean keepRunning = true;
                   
          while (keepRunning) {
              String[] options = {
                "Send messages",
                "Message Manager",
                "Quit"
            };
              
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
                    
            switch (choice) {
                case 0 -> sendMessages();
                case 1 -> messageManagerMenu();
                case 2, -1 -> {
                    keepRunning = false;
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }   

    // Send messages interface (from CODE 1), now also stores in arrays (CODE 2)
    public static void sendMessages() {
            String inputCount = JOptionPane.showInputDialog("How many messages would you like to send?");
            if (inputCount == null) return;
            int count;
            try {
                  count = Integer.parseInt(inputCount);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid number.");
                return;
            }
            
            for (int i = 0; i < count; i++) {
                messageNumber++;
                String messageID = generateMessageID();
                
          String recipient = JOptionPane.showInputDialog("Enter recipient number (+27xxxxxxxxx):");
            if (recipient == null || !recipient.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid number format.");
                i--;
                continue;
            }
            
            String message = JOptionPane.showInputDialog("Enter message (max 250 characters):");
            if (message == null) {
                i--;
                continue;
            }
            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null, "Message too long by " + (message.length() - 250) + " characters.");
                i--;
                continue;
            }
            
            String hash = generateMessageHash(messageID, messageNumber,message);
            
            String[] actions = {"Send", "Disregard", "Store"};
            int action = JOptionPane.showOptionDialog(null, "What do you want to do?", "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions[0]);
                 
            switch (action) {
                case 0 -> {
                    totalMessageSent++;
                    // Add to sent message arrays
                    sentMessages.add(message);
                    recipients.add(recipient);
                   messageIDs.add(messageID);
                    messageHashes.add(hash);
                    
                    displayMessageDetails(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                }
                case 1 -> {
                    disregardedMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                }
                case 2 -> {
                    storedMessages.add("recipient: " + recipient + " | Message: " + message);
                    writeMessageToJson(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message stored.");
                }
                default -> {
                    JOptionPane.showMessageDialog(null, "No action taken.");
                    i--;
                }
            }
         }                    
         JOptionPane.showMessageDialog(null, "Total message sent: " + totalMessageSent);
    }
    
    // --- Message Manager menu with all replacement methods ---
    public static void messageManagerMenu() {
        boolean running = true;
        while (running) {
            String[] options = {
                "Display all sent messages",
                "Display longest user message",
                "Search by message ID",
                "Search messages by recipient",
                "Delete message by hash",
                "Show full report",
                "Back to Main Menu"
            };
            int choice = JOptionPane.showOptionDialog(null, "Message Manager Options", "Message Manager",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
            
            switch (choice) {
                case 0 -> displaySendersAndRecipients();
                case 1 -> displayLongestMessage();
                case 2 -> {
                    String id = JOptionPane.showInputDialog("Enter Message ID:");
                    if (id != null) searchByMessageID(id);
                }
                case 3 -> {
                    String recipient = JOptionPane.showInputDialog("Enter Recipient Number:");
                    if (recipient != null) searchByRecipient(recipient);
                }
                case 4 -> {
                    String hash = JOptionPane.showInputDialog("Enter Message Task:");
                    if (hash != null) deleteMessageByTask(hash);
                }
                case 5 -> displayReport();
                case 6, -1 -> {
                    running = false;
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }
    
          // --- Message Manager methods --- 
    public static void displaySendersAndRecipients() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }
       StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Recipient: ").append(recipients.get(i)).append("\n");
            sb.append("Message: ").append(sentMessages.get(i)).append("\n");
            sb.append("Task: ").append(messageHashes.get(i)).append("\n");
            sb.append("ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("-----------------------------\n");
        }
         JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }
        String longest = "";
        for (String msg : sentMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest Sent Message:\n" + longest);
    }
    public static void searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                String msgDetails = "ecipient: " + recipients.get(i) + "\nMessage: " + sentMessages.get(i);
                JOptionPane.showMessageDialog(null, msgDetails, "Search Result", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }
    
    public static void searchByRecipient(String recipientNumber) {
        StringBuilder sb = new StringBuilder("Messages to " + recipientNumber + ":\n");
        boolean found = false;
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(recipientNumber)) {
                sb.append(sentMessages.get(i)).append("\n");
                found = true;
            }
        }
          for (String stored : storedMessages) {
            if (stored.contains(recipientNumber)) {
                sb.append(stored).append("\n");
                found = true;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipientNumber);
        } else {
            JOptionPane.showMessageDialog(null, sb.toString(), "Messages by Recipient", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    public static void deleteMessageByTask(String task) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(task)) {
                String msg = sentMessages.get(i);
                sentMessages.remove(i);
                recipients.remove(i);
                messageIDs.remove(i);
                messageHashes.remove(i);
                JOptionPane.showMessageDialog(null,"Deleted message:\n"  + msg);
                return;
            }
        }
          JOptionPane.showMessageDialog(null, "Message hash not found.");
    }
    
    public static void displayReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to report.");
            return;
        }
        StringBuilder sb = new StringBuilder("===== SENT MESSAGE REPORT =====\n");      
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Message ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("Message Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("Recipient: ").append(recipients.get(i)).append("\n");
            sb.append("Message: ").append(sentMessages.get(i)).append("\n");
            sb.append("-----------------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Message Report", JOptionPane.INFORMATION_MESSAGE);
    }

    // === Helper methods from Code 1 ===
    public static String generateMessagesID() {
        return String.format("%010d", new Random().nextInt(1_000_000_000));
    }

public static String generateMessageHash(String id, int num, String msg) {
        String[] words = msg.trim().split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : "";
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }
    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null, 
                "Message ID: " + id +
                "\nHash: " + hash +
                "\nRecipient: " + recipient +
                "\nMessage: " + message);
    }

        private static String generateMessageID() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    
     public static void writeMessageToJson(String messageID, String hash, String recipient, String message) {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append("  \"messageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append("  \"messageHash\": \"").append(hash).append("\",\n");
        jsonEntry.append("  \"recipient\": \"").append(recipient).append("\",\n");
        jsonEntry.append("  \"message\": \"").append(message.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("},\n");
     
        try (FileWriter file = new FileWriter("storage.json", true)) { // append mode
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file: " + e.getMessage());
        }      
     }
}
 