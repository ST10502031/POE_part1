/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package mycompany.quickchatapplication;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author abbyluxe
 */
public class QuickchatapplicationTest {
    
    public QuickchatapplicationTest() {
    }

    @Test
    public void testMain() {
    }

    @Test
    public void testRegisterUser() {
    }

    @Test
    public void testLoginUser() {
    }

    @Test
    public void testRunMessageSystem() {
    }

    @Test
    public void testSendMessages() {
    }

    @Test
    public void testGenerateMessageID() {
    }

    @Test
    public void testGenerateMessageHash() {
    }

    @Test
    public void testDisplayMessageDetails() {
    }

    @Test
    public void testWriteMessageToJSON() {
    }
    
}
