/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package mycompany.poechatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author abbyluxe
 */
public class POEChatAppTest {
    
    public POEChatAppTest() {
    }

    @Test
    public void testWriteMessageToJson() {
    }
    
}
