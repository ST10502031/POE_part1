/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.techwebdocs.prog5121w;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author abbyluxe
 */
public class Prog5121wIT {
    
    public Prog5121wIT() {
    }

    /**
     * Test of main method, of class Prog5121w.
     */
    @Test
    public void testMain() {
    }
    
}
