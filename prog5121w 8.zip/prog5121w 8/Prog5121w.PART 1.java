/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.techwebdocs.prog5121w;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author abbyluxe
 */
public class Prog5121w {

    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        ArrayList <Login>users = new ArrayList<>();//Store a number of users
        
        System.out.println("\n Welcome to our chat app 2026! Select options below:");
        
        while(true) {
            //display menu after each action
            System.out.println("\nMain Menu:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.println("4. Choose an option");
            
            int choice = scanner.nextInt();
            scanner.nextLine();//consume newline
            
            switch(choice){
                case 1 -> {
                    //Registration
                    System.out.print("Enter username");
                    String username = scanner.nextLine();
                    System.out.println("username successfully captured");
                    //validation of username 
                    boolean validUsername = username.contains("_")&&username.length()<=5;
                    if(!validUsername){
                        System.out.println("Username mst contain at least one underscore(_)and be no longer than 5 characters long.");
                        break;    
                    }
                    System.out.print("Enter password");
                    String password = scanner.nextLine();
                    System.out.println("Password success");
                    //validate password
                    boolean validPassword =password.length()>8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*") &&
                            password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
                    if(!validPassword) {
                        System.out.println("Password must be at least 8 characters long, contain upper case letter, number and special characters");
                        break;
                    }
                    System.out.print("Enter A SA phone number : (e.g +27831111111");
                    String phoneNumber = scanner.nextLine();
                    System.out.println("cellphone number is successfully added!");
                    //validate phone number
                    String regex ="\\+27[6-8]\\{8}";
                    if(!phoneNumber.matches(regex)){
                        System.out.println("invalid phone number format! use +27*********");
                        break;
                    }
                    //check if the user already exists
                    boolean userExists = users.stream().anyMatch(u ->u.getUsername().equals(username));
                    if(userExists){
                        System.out.println("Username already exist. Please choose another username");
                        break;
                    }
                    //add the new user
                    users.add(new Login(username, password, phoneNumber));
                    System.out.println("User registered successfully");
                    //Welcome the user and transition to login
                    System.out.println("Welcome "+ username + "!you can now log in");
                    System.out.println("Redirecting you to login page......\n");
                    
                    //immediately prompt the user to login
                    promptLogin(scanner, users);
                }       
                     
                case 2 -> {
                    //login
                    if(users.isEmpty()) {
                        System.out.println("No users are registered yet. Please register first.");
                        break;
                    }
                    //promt the user to login
                    promptLogin(scanner,users);
                }
        
                case 3 -> {
                    //Exit
                    System.out.println("Goodbye ! !");
                    scanner.close();
                    return;
                }
           
           default -> System.out.println("Invalid option. Please choose 1,2 or 3");
        } 
    }       
}      
    //method to handle login logic
    private static void promptLogin(Scanner scanner ,ArrayList<Login>users){
        System.out.print("Enter username");
        String enteredUsername = scanner.nextLine();
        System.out.print("Enter password");
        String enteredPassword = scanner.nextLine();
        //find user and attempt login
        Login user = users.stream().filter(u->u.getUsername().equals(enteredUsername)).findFirst().orElse(null);
                
                boolean LoginStatus = (user != null ) && user.LoginUser(enteredPassword);
                System.out.println(user !=null ? user.returnLoginStatus(LoginStatus):"user not found.");
                
    }
}
//Login class
 class Login{
    public String username;
    public String passwordHash;
    public String phoneNumber;
    public byte[]salt;
    
    public Login(String username, String password, String phoneNumber){
            this.username = username;
            this.salt = generateSalt();
            this.passwordHash = hashPassword(password, salt);      
            this.phoneNumber = phoneNumber;
            }
    public String getUsername(){
        return username;
}         
   public boolean LoginUser(String enteredPassword) {
       return this.passwordHash.equals(hashPassword(enteredPassword, salt));
}
public String  returnLoginStatus(boolean status){
    return status?"login successful! ":"Invalid username or password.";
}
//hash password with salt using SHA-256
private String hashPassword(String password, byte[]salt){
    try{
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(salt);//add salt to the hash
        byte[] hash= md.digest(password.getBytes());
        StringBuilder hexString= new StringBuilder();
        for(byte b: hash){
            hexString.append(String.format("%02xb", b));
        
        } 
        return hexString.toString();
        
  } catch (NoSuchAlgorithmException e) {
    throw new RuntimeException("Eror hashing password", e);
}

}
//Generate a random salt for password hashing
private byte[] generateSalt() {
    try{
        SecureRandom random = new SecureRandom();
        byte[] Salt = new byte[16];
        random.nextBytes(Salt);
        return Salt;
    }catch(Exception e) {
        throw new RuntimeException("Error generating salt",e);
    }
}
 }



        
